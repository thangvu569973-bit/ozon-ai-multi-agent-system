
from flask import Flask, render_template, request
from core.workflow import run_workflow

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    if request.method == "POST":
        product = {
            "name": request.form.get("name"),
            "cost": request.form.get("cost"),
            "category": request.form.get("category")
        }
        result = run_workflow(product)
    return render_template("index.html", result=result)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=3000)
