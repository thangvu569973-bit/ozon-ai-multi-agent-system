
# Ozon AI SaaS System

## Deploy
1. Upload to GitHub
2. Connect Railway
3. Auto deploy

## Features
- Multi-Agent AI workflow
- Product analysis
- Listing generation
- Ads optimization

## Run locally
pip install -r requirements.txt
python app.py
