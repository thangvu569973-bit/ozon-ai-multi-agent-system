
from agents.product_agent import analyze_product
from agents.listing_agent import generate_listing
from agents.ads_agent import generate_ads_strategy
from agents.analytics_agent import analyze_performance

def run_workflow(product):
    a = analyze_product(product)
    l = generate_listing(a)
    ad = generate_ads_strategy(a)
    o = analyze_performance({"CTR":"2%","ROI":"1.5"})
    return {"analysis":a,"listing":l,"ads":ad,"optimization":o}
