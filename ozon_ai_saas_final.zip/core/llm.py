
def call_llm(prompt):
    return "AI Output: " + prompt[:120]
