from core.llm import call_llm
def analyze_performance(p): return call_llm(str(p))