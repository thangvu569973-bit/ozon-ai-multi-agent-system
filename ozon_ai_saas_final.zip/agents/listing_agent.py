from core.llm import call_llm
def generate_listing(p): return call_llm(str(p))