from core.llm import call_llm
def analyze_product(p): return call_llm(str(p))