from core.llm import call_llm
def generate_ads_strategy(p): return call_llm(str(p))